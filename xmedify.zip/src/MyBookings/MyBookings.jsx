import BookingModal from "../components/BookingModal/BookingModal";

export default function MyBookings() {
  return (
    <div>
      <BookingModal />
    </div>
  );
}
